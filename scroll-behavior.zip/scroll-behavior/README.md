# 简易版轮播组件
## 背景
实现一个很简单的自动轮播的效果

思考： 传统的 swiper 太重了，里面封装了很多我们不需要的功能，一个简单的功能没必要那么中的文件。那就自己实现吧

实现方式有千千万万，那么如何才用最少的代码最优雅的实现呢？是否可以推翻传统的实现，使用 css 的某些特效实现呢？

肯定可以的呀

## 用哪些 css 属性实现
[scroll-behavior](https://developer.mozilla.org/en-US/docs/Web/CSS/scroll-behavior): 让页面平滑的滚动，滚动效果又湿又滑，用户体验会很不错

[scroll-snap-type](https://developer.mozilla.org/en-US/docs/Web/CSS/scroll-snap-type): 滚动到了一个临界点，是回到最初的原点还是滚到终点

[scroll-snap-align](https://developer.mozilla.org/en-US/docs/Web/CSS/scroll-snap-align): 上面那个属性的临界点是在具体的哪一个点？

[caniuse](https://caniuse.com/):可以查看这些属性的兼容性

如果有某一个属性不兼容怎么办？自己js打补丁呗 比如组件里面实现的：scroll-behavior

## 有哪些优点
1. 全部原生js实现，简单轻量，没有框架限制

2. 图片有懒加载 => [浏览器IMG图片原生懒加载loading=”lazy”实践指南](https://www.zhangxinxu.com/wordpress/2019/09/native-img-loading-lazy/)

3. 有图片失败的异常处理 => [图片加载失败后CSS样式处理最佳实践](https://www.zhangxinxu.com/wordpress/2020/10/css-style-image-load-fail/)

4. 不支持 scroll-behavior 有兼容处理

5. 可以npm安装使用

## 怎么使用
1. 本地下载js/css使用引入使用

[本地下载js使用Deom](https://yux.yuewen.com/jsbin/qaf/1/edit?html,css,js,output)

2. 可以 npm 发布 




